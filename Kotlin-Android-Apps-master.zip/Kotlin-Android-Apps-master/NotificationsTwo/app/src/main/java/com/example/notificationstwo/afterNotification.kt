package com.example.notificationstwo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class afterNotification : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_after_notification)
    }
}